
function preloadImages(){


$j.preload( 
'images/character_guide_front.png',
'images/character_guide_front_2.png',
'images/character_guide_pose2.png',
'images/character_guide_pose3.png',
'images/character_guide_pose4.png',
'images/character_guide_pose5.png',
'images/character_guide_pose6.png',
'images/femalePose1.png',
'images/femalePose2.png',
'images/femalePose3.png',
'images/femalePose4.png',
'images/femalePose5.png',
'images/manPose1.png',
'images/manPose2.png',
'images/manPose3.png',
'images/manPose4.png',
'images/manPose5.png',
'images/manJetpack_fly.png',
'images/manIdle.png',
'images/infobit_06_small_b.png',
'images/infobit_05_small_b.png',
'images/infobit_04_small_b.png',
'images/infobit_03_small_b.png',
'images/infobit_02_small.png',
'images/infobit_01_small_b.png'
);


}





