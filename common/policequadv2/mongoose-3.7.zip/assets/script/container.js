var $j= jQuery.noConflict(); 
var wrapperCurrentPage = "Main";

var loadedComps 	= {};

var gameScore 		= 0;
var lessonLocation  =0;
var avatar_gender ="male";
var count=0;
var containerClass;
var avatarName ="";

//hideAllScreens();
function restaart(){
currentScene="scene"+lessonLocation;
avatarName ="";
}
$j(document).ready(function() { 
AdobeEdge.bootstrapCallback(function(compId) {
	count++;
	loadedComps[compId] = AdobeEdge.getComposition(compId);
//	console.log("compId "+compId);
	containerClass	= window;
	
	if(count==1)
	{
		
		loadInstructionXML();
		
	//	loadedComps[compId].getStage().play(1);
		
	}

	AdobeEdge.Symbol.bindTimelineAction(compId, "stage", "Default Timeline", "complete", function(sym, e) {		

	});
	
});
});


var quizXML;

function loadInstructionXML()
{

	///load questions xml
	var xmlLoader2 	= new loadXML('assets/xml/quiz.xml', convXMLLoadedHandler);
	xmlLoader2.loadXMLFile();

}


function convXMLLoadedHandler(xmlDoc)
{

	
	quizXML= $(xmlDoc);
	jQuery('.menubuttons').mouseout(function() {
		if(jQuery(this).hasClass('enable')) return true; 
		jQuery(this).css('background-image',jQuery(this).css("background-image").replace("_Over","_Normal"));
		
		
	}) .mouseover(function() {
		if(jQuery(this).hasClass('enable')) return true; 
		jQuery(this).css('background-image',jQuery(this).css("background-image").replace("_Normal","_Over"));
	}).click(function() {
		if(jQuery(this).hasClass('enable')) {return true}; 
		//togglePage();
		jQuery(this).addClass('enable');
		jQuery(this).css('background-image',jQuery(this).css("background-image").replace("_Over","_Click").replace("_Normal","_Click"));
		
		
		
	});
	$("#main").show();
	console.log("kya");
	//loadedComps["main"].getStage().play(1);
	
	
}

	
/* function LogoClicked(){
$("#Main").css({"height": "650px"});
	jQuery('.Iframe').html('<iframe style="width:1024px; height:650px" src="scr_Home.html" frameborder="0" scrolling="no" id="myFrame"></iframe>');
} */



Array.prototype.shuffle = function() {
    var input = this;
     
    for (var i = input.length-1; i >=0; i--) {
     
        var randomIndex = Math.floor(Math.random()*(i+1)); 
        var itemAtIndex = input[randomIndex]; 
         
        input[randomIndex] = input[i]; 
        input[i] = itemAtIndex;
    }
    return input;
}
function hideAllScreens()
{
	
	$("#main").hide();

}

/* function togglePage(){
		jQuery('.menubuttons').each(function (){
		
		jQuery(this).removeClass('enable');
		jQuery(this).css('background-image',jQuery(this).css("background-image").replace("_Over","_Normal").replace("_Click","_Normal"));
		});
		
		//jQuery('.menubuttons').css('background-image',jQuery(this).css("background-image").replace("_Normal","_Click"));
}
 */

